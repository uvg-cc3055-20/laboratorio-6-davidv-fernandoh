Please download the sample apps at https://developer.vuforia.com/downloads/samples and unpack them in this folder
